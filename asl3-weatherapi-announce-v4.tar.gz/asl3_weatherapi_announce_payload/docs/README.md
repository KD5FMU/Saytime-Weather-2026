# ASL3 WeatherAPI Announce Payload

This package includes `say24time.pl`.

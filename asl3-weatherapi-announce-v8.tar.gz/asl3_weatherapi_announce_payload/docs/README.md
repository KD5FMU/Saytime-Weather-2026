# ASL3 WeatherAPI Announce Payload v6

This package includes the uploaded WA3DSP say24time.pl patched for ASL3.

Important:
- `say24time.pl` uses `/usr/local/share/asterisk/sounds/custom`
- WeatherAPI config lives at `/etc/asterisk/local/weatherapi.ini`
- Weather cache refresh is handled by systemd timer
- Hourly voice announcement is handled by root crontab

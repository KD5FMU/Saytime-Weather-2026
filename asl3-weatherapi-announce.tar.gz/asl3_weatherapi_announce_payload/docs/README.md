# ASL3 WeatherAPI Announce Payload

This payload is intended for ASL3 on Debian 12/13. It keeps the KD5FMU/WA3DSP recorded GSM voice-file workflow and replaces live top-of-hour weather lookups with a local WeatherAPI cache.

Main files installed:

- `/usr/local/sbin/asl3-weatherapi-update.sh` fetches WeatherAPI current conditions and writes `/tmp/weatherapi.json`, `/tmp/temperature`, and `/tmp/condition.gsm`.
- `/usr/local/sbin/weather.sh` is the compatibility wrapper called by the original `saytime.pl`.
- `/etc/systemd/system/asl3-weatherapi-update.timer` updates the cache every 15 minutes with randomized delay.
- `/etc/asterisk/local/weatherapi.ini` stores API key, location, and settings.

This system does not use text-to-speech.

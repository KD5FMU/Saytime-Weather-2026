# ASL3 WeatherAPI Announce Cache

This package is designed for AllStarLink 3 on Debian 12/13.

It supports two install paths:

1. Migration mode: a node already has KD5FMU Time-Weather-Announce installed. Existing `saytime.pl` is preserved. The old top-of-hour weather lookup is replaced by a cached `/usr/local/sbin/weather.sh`.
2. Fresh install mode: no previous Time-Weather-Announce install exists. The installer adds a fallback ASL3 `saytime.pl`, cached weather scripts, config files, and an optional hourly cron line when location and node number are supplied.

## Main files

- `/usr/local/sbin/asl3-weatherapi-update.sh`
- `/usr/local/sbin/asl3-tempest-update.sh`
- `/usr/local/sbin/random_wx_start.sh`
- `/usr/local/sbin/weather.sh`
- `/usr/local/sbin/show_weatherapi.sh`
- `/usr/local/sbin/saytime.pl` fresh installs only; existing copies are preserved
- `/etc/asterisk/local/weatherapi.ini`
- `/etc/asterisk/local/tempest.ini`
- `/etc/systemd/system/asl3-weatherapi-update.timer`

## Configure

Edit:

```bash
sudo nano /etc/asterisk/local/weatherapi.ini
```

Set:

```bash
API_KEY="your_weatherapi_key"
LOCATION="your_zip_or_city_or_lat_long"
TEMPERATURE_MODE="F"
```

## Test

```bash
sudo /usr/local/sbin/asl3-weatherapi-update.sh
/usr/local/sbin/show_weatherapi.sh
/usr/local/sbin/weather.sh v
sudo /usr/local/sbin/saytime.pl 74437 58176
```

# ASL3 WeatherAPI Announce Payload

- Weather cache refresh: systemd timer
- Hourly announcement: root crontab running saytime.pl
- Voice method: recorded sound files from the original KD5FMU Time-Weather-Announce installer
- Configuration: /etc/asterisk/local/weatherapi.ini

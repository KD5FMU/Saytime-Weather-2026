# ASL3 WeatherAPI Announce Payload

This payload supports ASL3 Debian 12/13 weather announcements using cached WeatherAPI data.

- Weather cache refresh: systemd timer
- Hourly announcement: root crontab running `saytime.pl` or `say24time.pl`
- Voice method: recorded sound files from the original KD5FMU Time-Weather-Announce installer
- Configuration: `/etc/asterisk/local/weatherapi.ini`

Included scripts:

- `asl3-weatherapi-update.sh`
- `weather.sh`
- `show_weatherapi.sh`
- `random_wx_start.sh`
- `say24time.pl`

`bin/say24time.pl` is an ASL3-safe compatibility wrapper that calls `/usr/local/sbin/saytime.pl` with the same arguments. The installer preserves an existing `/usr/local/sbin/say24time.pl` if one is already present.
